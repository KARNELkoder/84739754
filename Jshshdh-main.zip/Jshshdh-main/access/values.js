// Активировать документы (true - включены, false - отключены)
var isRightsEnabled = true; // Права
var isCovidCertificateEnabled = true; // COVID-сертификат

// Общее
var birthdate = "27.03.2005"; // Дата рождения
var fullname = "Корнієнко Олександр Сергійович" // ФИО
var name = "Имя" // Имя

// Паспорт
var passport_id = "3872011238" // Номер паспорта

// КПП
var kpp_id = "3872011238" // ИНН

// Права
var rights_valid_until = "11.09.2027" // Права "Дійсні до"
var rights_categories = "A, B" // Права "Категорії"
var rights_tsc = "ТСЦ 8631" // Права "Видав
var rights_id = "KBE968639" // Права "Серія та номер""

// COVID-сертификат
var covid_valid_until = "09.08.2023" // Сертификат "Дійсний до"
var covid_certificate_id = "URN:UVCI:01:UA:0<br>E55669376876888<br>B9E2520C4F88930" // Номер сертификата (<br> - перенос строки)
